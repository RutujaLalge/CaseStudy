package com.giftDelivery.ecom.services.auth;

import com.giftDelivery.ecom.dto.SignupRequest;
import com.giftDelivery.ecom.dto.UserDto;

public interface AuthService {
	
	UserDto createCustomer(SignupRequest signupRequest);
	
	Boolean hasCustomerWithEmail(String email);

//	UserDto updateCustomer(Long customerId, SignupRequest sign);
//
//	UserDto findCustomerById(Long customerId);
//
//	boolean deleteCustomerById(Long customerId);

}
