package com.giftDelivery.ecom.enums;

public enum UserRole {
	
	ADMIN,
	
	CUSTOMER

}
