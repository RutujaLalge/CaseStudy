package com.giftDelivery.ecom.services.admin.category;

import java.util.List;

import com.giftDelivery.ecom.dto.CategoryDto;
import com.giftDelivery.ecom.entity.Category;

public interface CategoryService {
	
	Category createcategory(CategoryDto categoryDto);
	
	List<Category> getAllCategories();
}
