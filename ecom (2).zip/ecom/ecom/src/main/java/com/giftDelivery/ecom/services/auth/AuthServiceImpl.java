package com.giftDelivery.ecom.services.auth;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.giftDelivery.ecom.dto.SignupRequest;
import com.giftDelivery.ecom.dto.UserDto;
import com.giftDelivery.ecom.entity.Order;
import com.giftDelivery.ecom.entity.User;
import com.giftDelivery.ecom.enums.OrderStatus;
import com.giftDelivery.ecom.enums.UserRole;
import com.giftDelivery.ecom.repository.OrderRepository;
import com.giftDelivery.ecom.repository.UserRepository;

import jakarta.annotation.PostConstruct;

@Service
public class AuthServiceImpl implements AuthService{
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private OrderRepository orderRepository;
	
	public UserDto createCustomer(SignupRequest signupRequest)
	{
		User user = new User();
		
		user.setEmail(signupRequest.getEmail());
		user.setName(signupRequest.getName());
		user.setPassword(signupRequest.getPassword());
		user.setRole(UserRole.CUSTOMER);
		
		User createdUser = userRepository.save(user);
		
		Order order = new Order();
		order.setAmount(0L);
		order.setTotalAmount(0L);
		order.setDiscount(0L);
		order.setUser(createdUser);
		order.setOrderStatus(OrderStatus.Pending);
		orderRepository.save(order);
		
		UserDto userDto = new UserDto();
		userDto.setId(createdUser.getId());
		
		return userDto;
	}
	

	@Override
	public Boolean hasCustomerWithEmail(String email) {
		// TODO Auto-generated method stub
		return userRepository.findFirstByEmail(email).isPresent();
	}
	
	@PostConstruct
	public void createAdminAccount()
	{
		User adminAccount = userRepository.findByRole(UserRole.ADMIN);
		if(null == adminAccount)
		{
			User user = new User();
			user.setEmail("admin@test.com");
			user.setName("admin");
			user.setRole(UserRole.ADMIN);
			user.setPassword("Admin@123");
			userRepository.save(user);
		}
	}
	
	

}
