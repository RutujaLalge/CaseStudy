package com.giftDelivery.ecom.controller;

import java.io.IOException;
import java.util.Optional;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.giftDelivery.ecom.dto.AuthenticationRequest;
import com.giftDelivery.ecom.dto.SignupRequest;
import com.giftDelivery.ecom.dto.UserDto;
import com.giftDelivery.ecom.repository.UserRepository;
import com.giftDelivery.ecom.services.auth.AuthService;

import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {
	
	private AuthService authService;
	
	private AuthenticationManager authenticationManager;
	
	private UserDetailsService userDetailsService;
	
	private UserRepository userRepository;
	
	//private JwtUtil jwtUtil;
	
	@PostMapping("/authenticate")
	public void createAuthenticationToken(@RequestBody AuthenticationRequest authenticationRequest, 
			HttpServletResponse response)throws IOException, JSONException
	{
		
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername()
					,authenticationRequest.getPassword()));
			
		}
		catch(BadCredentialsException e)
		{
			throw new BadCredentialsException("Incorrect username or password.");
		}
		
//		final UserDetails userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUsername());
//		Optional<User> optionalUser = userRepository.findFirstByEmail(userDetails.getUsername());
//		//final String jwt.g
//		
//		if(optionalUser.isPresent())
//		{
//			response.getWriter().write(new JSONObject())
//			
//		}
	}
	

	
	@PostMapping("/signup")
	public ResponseEntity<?> signupCustomer(@RequestBody SignupRequest signupRequest){
		
		if(authService.hasCustomerWithEmail(signupRequest.getEmail())) {
			return new ResponseEntity<>("Customer alredy exist with this email",HttpStatus.NOT_ACCEPTABLE);
		}
		
		UserDto dto=authService.createCustomer(signupRequest);
		
		if(dto==null) {
			return new ResponseEntity<>("Customer not created,Come again later",HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(dto,HttpStatus.CREATED);
	}
	
	

}
