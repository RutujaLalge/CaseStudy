package com.giftDelivery.ecom.services.customer;

import java.util.List;

import com.giftDelivery.ecom.dto.ProductDto;

public interface CustomerProductService {
	
	
	List<ProductDto> searchProductByTitle(String name); 
	
	List<ProductDto> getAllProducts();
	
	

}
