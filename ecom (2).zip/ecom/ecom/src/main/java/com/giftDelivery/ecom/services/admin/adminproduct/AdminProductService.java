package com.giftDelivery.ecom.services.admin.adminproduct;

import java.io.IOException;
import java.util.List;

import com.giftDelivery.ecom.dto.ProductDto;

public interface AdminProductService {
	
	ProductDto addProduct(ProductDto productDto)throws IOException;
	
	List<ProductDto> getAllProducts();
	
	List<ProductDto> getAllProductsByName(String name);
	
	boolean deleteproduct(Long id);

}
