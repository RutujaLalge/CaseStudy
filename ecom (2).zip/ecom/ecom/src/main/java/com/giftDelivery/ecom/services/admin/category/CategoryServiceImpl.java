package com.giftDelivery.ecom.services.admin.category;

import java.util.List;

import org.springframework.stereotype.Service;

import com.giftDelivery.ecom.dto.CategoryDto;
import com.giftDelivery.ecom.entity.Category;
import com.giftDelivery.ecom.repository.CategoryRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CategoryServiceImpl implements CategoryService{
	
	private CategoryRepository categoryRepository;
	
	public Category createcategory(CategoryDto categoryDto) {
		Category category = new Category();
		category.setName(category.getName());
		category.setDescription(category.getDescription());
		
		return categoryRepository.save(category);
		
		
		
	}
	
	public List<Category> getAllCategories()
	{
		return categoryRepository.findAll();
	}

	

}
