package com.giftDelivery.ecom.services.customer.cart;

import org.springframework.http.ResponseEntity;

import com.giftDelivery.ecom.dto.AddProductInCartDto;
import com.giftDelivery.ecom.dto.OrderDto;

public interface CartService {
	
	ResponseEntity<?> addProductToCart(AddProductInCartDto addProductInCartDto);
	
	OrderDto getCartByUserId(Long userId);

}
