package com.giftDelivery.ecom.enums;

public enum OrderStatus {
	
	Pending,
	
	Placed,
	
	Shipped,
	
	Delivered
	
	

}
